#include "parser/Parser.h"

int main()
{
    compiler::Parser parser("../test_programs/quick_recursive.ts", "test1.asm");
    parser.parse();
    parser.generate();

    return 0;
}


