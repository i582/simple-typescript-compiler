#pragma once

#include "asm/asm.h"


namespace compiler
{

    class Parser
    {
    private:
        Lexer* m_lex;
        Ast* m_tree;

        Asm* m_asm;


    public:
        Parser(const string& file_path_, const string& outputFile);
        ~Parser();

    public:
        void parse();
        void generate();

    private:
        void error(const string& message);

    private: // grammar functions
        Node* primary_expression();
        Node* parenthesized_expression();
        Node* postfix_expression();

        Node* argument_expression_list();

        Node* unary_expression();
        Node* exponentiation_expression();
        Node* multiplicative_expression();
        Node* additive_expression();
        Node* relational_expression();
        Node* equality_expression();
        Node* logical_and_expression();
        Node* logical_or_expression();
        Node* conditional_expression();
        Node* assignment_expression();
        Node* expression();
        Node* constant_expression();


        Node* statement();
        Node* compound_statement();
        Node* statement_list();
        Node* expression_statement();
        Node* selection_statement();
        Node* iteration_statement();

        Node* declaration_type();
        Node* declaration_statement();

        Node* initializer();
        Node* initializer_list();

        Node* function_argument();
        Node* function_argument_list();
        Node* function_statement();

        Node* operator_statement();

    };


}

