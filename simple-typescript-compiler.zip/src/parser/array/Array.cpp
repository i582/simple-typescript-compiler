#include "Array.h"

compiler::Array::Array(const string& name, size_t size, const vector<VariableValue>& values, class Variable* var)
{
    this->m_name = name;
    this->m_size = size;
    this->m_values = values;
    this->m_variable = var;
}

std::string compiler::Array::name() const
{
    return m_name;
}

size_t compiler::Array::size() const
{
    return m_size;
}

compiler::Variable* compiler::Array::variable() const
{
    return m_variable;
}

void compiler::Array::values(const std::vector<compiler::VariableValue>& values)
{
    m_values = values;
}

const std::vector<compiler::VariableValue>& compiler::Array::values() const
{
    return m_values;
}

std::string compiler::Array::values_to_string() const
{
    string result;

    for (int i = m_values.size() - 1; i >= 0; --i)
    {
        const auto& value = m_values[i];

        auto type = Variable::type_variable_value(value);

        switch (type)
        {
            case VariableType::NUMBER:
            {
                result += std::to_string((int)std::get<number>(value));
                break;
            }
            case VariableType::BOOLEAN:
            {
                result += std::to_string(std::get<bool>(value));
                break;
            }
            case VariableType::STRING:
            {
                result += std::get<string>(value);
                result += ",0";
                break;
            }

            case VariableType::UNDEFINED:
            case VariableType::VOID:
            case VariableType::ANY:
            case VariableType::NUMBER_ARRAY:
            case VariableType::BOOLEAN_ARRAY:
            case VariableType::STRING_ARRAY:
            case VariableType::VOID_ARRAY:
                break;
        }

        result += ",";
    }

    result.pop_back();

    return result;
}
