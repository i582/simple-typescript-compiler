#include "Parser.h"

compiler::Parser::Parser(const std::string& file_path_, const string& outputFile)
{
    m_lex = new Lexer(file_path_);
    m_tree = new Ast();

    m_asm = new Asm(outputFile, m_tree);


    m_lex->parse();
    m_lex->print_tokens();
}

compiler::Parser::~Parser()
{
    delete m_lex;
    delete m_tree;

    delete m_asm;
}

void compiler::Parser::error(const std::string& message)
{
    cout << "Parse error: " << message << " ";

    cout << "Current token: '" << m_lex->current_token().lexeme() + "' (" +
                                  std::to_string(m_lex->current_token().line()) + ", " +
                                  std::to_string(m_lex->current_token().pos()) + ")"
                                 << endl;

    m_lex->print_current_token_line();

    throw std::logic_error(message);
}

void compiler::Parser::parse()
{
    Node* new_node = statement();
    m_tree->m_root = new Node(NodeType::PROGRAM, "", new_node);


    m_tree->designate_blocks();

    m_tree->mark_block();


    m_tree->designate_variables();
    m_tree->designate_global_variables();
    m_tree->designate_arrays();


    m_tree->designate_functions();
    m_tree->mark_break_continue_operators();
    m_tree->mark_return_operator();







    // checks
    m_tree->check_const();
    m_tree->check_array();
    m_tree->check_functions_call();
    m_tree->check_expression();
    

    m_tree->print(m_tree->m_root, 0);


    m_tree->print_functions_table();
    m_tree->print_variable_table();
}

compiler::Node* compiler::Parser::primary_expression()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() == TokenType::NUMBER_CONST)
    {
        string number_str = m_lex->current_token().lexeme();


        number number_val = stold(number_str);
        temp_node = new Node(NodeType::NUMBER_CONST, number_val);

        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::STRING_CONST)
    {
        string str = m_lex->current_token().lexeme();

        temp_node = new Node(NodeType::STRING_CONST, str);
        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::TRUE)
    {
        temp_node = new Node(NodeType::BOOLEAN_CONST, 1);

        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::FALSE)
    {
        temp_node = new Node(NodeType::BOOLEAN_CONST, 0);

        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::NON_TERMINAL)
    {
        string name = m_lex->current_token().lexeme();

        if (!Lexer::is_correct_identifier(name))
        {
            error("Invalid identifier: '" + m_lex->current_token().lexeme() + "'");
        }

        m_lex->next_token();


        if (m_lex->current_token_type() == TokenType::LPAR)
        {
            temp_node = new Node(NodeType::FUNCTION_CALL, name);
        }
        else
        {
            temp_node = new Node(NodeType::USING_VARIABLE, name);
        }

    }
    else if (m_lex->current_token_type() == TokenType::LPAR)
    {
        temp_node = parenthesized_expression();
    }
    else if (m_lex->current_token_type() == TokenType::LSQR)
    {
        temp_node = initializer();
    }
    else if (m_lex->current_token_type() == TokenType::LET ||
             m_lex->current_token_type() == TokenType::CONST)
    {
        temp_node = declaration_statement();
    }
    else if (m_lex->current_token_type() == TokenType::NEW)
    {
        temp_node = operator_statement();
    }
    else
    {
        cout << "What happens? Current token: '" + m_lex->current_token().lexeme() + "' ("
             << m_lex->current_token().line() << ", " << m_lex->current_token().pos() << ")" << endl;
    }

    return temp_node;
}

compiler::Node* compiler::Parser::parenthesized_expression()
{
    if (m_lex->current_token_type() != TokenType::LPAR)
    {
        error("'(' expected!");
    }
    m_lex->next_token();


    auto temp_node = expression();


    if (m_lex->current_token_type() != TokenType::RPAR)
    {
        error("')' expected!");
    }
    m_lex->next_token();

    return temp_node;
}

compiler::Node* compiler::Parser::postfix_expression()
{
    Node* temp_node = primary_expression();

    if (m_lex->current_token_type() == TokenType::LSQR)
    {
        m_lex->next_token();
        auto temp_expression = expression();

        if (m_lex->current_token_type() != TokenType::RSQR)
        {
            error("']' expected!");
        }
        m_lex->next_token();

        temp_node = new Node(NodeType::INDEX_CAPTURE, 0, temp_node, temp_expression);
    }
    else if (m_lex->current_token_type() == TokenType::LPAR)
    {
        m_lex->next_token();
        auto function_name = any_cast<string>(temp_node->value);
        auto temp_argument_expression_list = argument_expression_list();

        if (m_lex->current_token_type() != TokenType::RPAR)
        {
            error("')' expected!");
        }
        m_lex->next_token();

        temp_node = new Node(NodeType::FUNCTION_CALL, function_name, temp_argument_expression_list);
    }
    else if (m_lex->current_token_type() == TokenType::INC)
    {
        m_lex->next_token();
        temp_node = new Node(NodeType::AFTER_INC, 0, temp_node);
    }
    else if (m_lex->current_token_type() == TokenType::DEC)
    {
        m_lex->next_token();
        temp_node = new Node(NodeType::AFTER_DEC, 0, temp_node);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::argument_expression_list()
{
    Node* temp_node = nullptr;

    while (m_lex->current_token_type() != TokenType::RPAR)
    {
        auto temp_function_argument = assignment_expression();

        temp_node = new Node(NodeType::FUNCTION_ARGS, "", temp_function_argument, temp_node);

        if (m_lex->current_token_type() == TokenType::COMMA)
        {
            m_lex->next_token();
        }
    }

    return temp_node;
}

compiler::Node* compiler::Parser::unary_expression()
{
    Node* temp_node = nullptr;


    if (m_lex->current_token_type() == TokenType::INC)
    {
        m_lex->next_token();
        temp_node = unary_expression();
        temp_node = new Node(NodeType::BEFORE_INC, 0, temp_node);
    }
    else if (m_lex->current_token_type() == TokenType::DEC)
    {
        m_lex->next_token();
        temp_node = unary_expression();
        temp_node = new Node(NodeType::BEFORE_DEC, 0, temp_node);
    }
    else if (Token::is_unary_operator(m_lex->current_token_type()))
    {
        auto type = NodeType::UNARY_PLUS;

        if (m_lex->current_token_type() == TokenType::MINUS)
            type = NodeType::UNARY_MINUS;
        else if (m_lex->current_token_type() == TokenType::EXCLAMATION)
            type = NodeType::UNARY_EXCLAMATION;

        m_lex->next_token();
        temp_node = unary_expression();
        temp_node = new Node(type, 0, temp_node);
    }
    else
    {
        temp_node = postfix_expression();
    }


    return temp_node;
}

compiler::Node* compiler::Parser::exponentiation_expression()
{
    Node* temp_node = unary_expression();

    if (m_lex->current_token_type() == TokenType::STAR_STAR)
    {
        m_lex->next_token();
        auto temp_expression = unary_expression();

        temp_node = new Node(NodeType::EXPONENTIATION, "", temp_node, temp_expression);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::multiplicative_expression()
{
    Node* temp_node = exponentiation_expression();


    if (m_lex->current_token_type() == TokenType::STAR || m_lex->current_token_type() == TokenType::SLASH)
    {
        NodeType temp_type = NodeType::MUL;

        if (m_lex->current_token_type() == TokenType::SLASH)
        {
            temp_type = NodeType::DIV;
        }

        m_lex->next_token();

        auto temp_unary_expression = multiplicative_expression();

        temp_node = new Node(temp_type, "", temp_node, temp_unary_expression);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::additive_expression()
{
    Node* temp_node = multiplicative_expression();


    if (m_lex->current_token_type() == TokenType::PLUS || m_lex->current_token_type() == TokenType::MINUS)
    {
        NodeType temp_type = NodeType::ADD;

        if (m_lex->current_token_type() == TokenType::MINUS)
        {
            temp_type = NodeType::SUB;
        }

        m_lex->next_token();

        auto temp_multiplicative_expression = additive_expression();

        temp_node = new Node(temp_type, "", temp_node, temp_multiplicative_expression);
    }


    return temp_node;
}

compiler::Node* compiler::Parser::relational_expression()
{
    Node* temp_node = additive_expression();


    if (m_lex->current_token_type() == TokenType::LESS)
    {
        m_lex->next_token();
        auto temp_additive_expression = additive_expression();

        temp_node = new Node(NodeType::LESS, "", temp_node, temp_additive_expression);
    }
    else if (m_lex->current_token_type() == TokenType::GREATER)
    {
        m_lex->next_token();
        auto temp_additive_expression = additive_expression();

        temp_node = new Node(NodeType::GREATER, "", temp_node, temp_additive_expression);
    }
    else if (m_lex->current_token_type() == TokenType::GREATER_EQUAL)
    {
        m_lex->next_token();
        auto temp_additive_expression = additive_expression();

        temp_node = new Node(NodeType::GREATER_EQUAL, "", temp_node, temp_additive_expression);
    }
    else if (m_lex->current_token_type() == TokenType::LESS_EQUAL)
    {
        m_lex->next_token();
        auto temp_additive_expression = additive_expression();

        temp_node = new Node(NodeType::LESS_EQUAL, "", temp_node, temp_additive_expression);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::equality_expression()
{
    Node* temp_node = relational_expression();


    if (m_lex->current_token_type() == TokenType::EQUAL)
    {
        m_lex->next_token();
        auto temp_relational_expression = relational_expression();

        temp_node = new Node(NodeType::EQUAL, "", temp_node, temp_relational_expression);
    }
    else if (m_lex->current_token_type() == TokenType::NOT_EQUAL)
    {
        m_lex->next_token();
        auto temp_relational_expression = relational_expression();

        temp_node = new Node(NodeType::NOT_EQUAL, "", temp_node, temp_relational_expression);
    }


    return temp_node;
}

compiler::Node* compiler::Parser::logical_and_expression()
{
    Node* temp_node = equality_expression();


    if (m_lex->current_token_type() == TokenType::AND)
    {
        m_lex->next_token();
        auto temp_logical_and_expression = logical_and_expression();

        temp_node = new Node(NodeType::LOGICAL_AND, "", temp_node, temp_logical_and_expression);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::logical_or_expression()
{
    Node* temp_node = logical_and_expression();


    if (m_lex->current_token_type() == TokenType::OR)
    {
        m_lex->next_token();
        auto temp_logical_or_expression = logical_or_expression();

        temp_node = new Node(NodeType::LOGICAL_OR, "", temp_node, temp_logical_or_expression);
    }


    return temp_node;
}

compiler::Node* compiler::Parser::conditional_expression()
{
    Node* temp_node = logical_or_expression();


    if (m_lex->current_token_type() == TokenType::QUESTION)
    {
        m_lex->next_token();
        auto temp_expression = expression();

        if (m_lex->current_token_type() != TokenType::COLON)
        {
            error("':' expected!");
        }
        m_lex->next_token();

        auto temp_conditional_expression = conditional_expression();

        temp_node = new Node(NodeType::IF_ELSE, "", temp_node, temp_expression, temp_conditional_expression);
    }



    return temp_node;
}

compiler::Node* compiler::Parser::assignment_expression()
{
    Node* temp_node = conditional_expression();


    if (Token::is_assignment_operator(m_lex->current_token_type()))
    {
        auto current_token_type = m_lex->current_token_type();

        m_lex->next_token();
        auto temp_assignment_expression = assignment_expression();


        if (current_token_type == TokenType::ASSIGN)
        {
            temp_node = new Node(NodeType::SET, "", temp_node, temp_assignment_expression);
        }
        else if (current_token_type == TokenType::ADD_ASSIGN)
        {
            auto temp_math = new Node(NodeType::ADD, "", temp_node, temp_assignment_expression);
            temp_node = new Node(NodeType::SET, "", temp_node, temp_math);
        }
        else if (current_token_type == TokenType::SUB_ASSIGN)
        {
            auto temp_math = new Node(NodeType::SUB, "", temp_node, temp_assignment_expression);
            temp_node = new Node(NodeType::SET, "", temp_node, temp_math);
        }
        else if (current_token_type == TokenType::MUL_ASSIGN)
        {
            auto temp_math = new Node(NodeType::MUL, "", temp_node, temp_assignment_expression);
            temp_node = new Node(NodeType::SET, "", temp_node, temp_math);
        }
        else if (current_token_type == TokenType::DIV_ASSIGN)
        {
            auto temp_math = new Node(NodeType::DIV, "", temp_node, temp_assignment_expression);
            temp_node = new Node(NodeType::SET, "", temp_node, temp_math);
        }

    }

    return temp_node;
}

compiler::Node* compiler::Parser::expression()
{
    Node* temp_node = assignment_expression();

    temp_node = new Node(NodeType::EXPRESSION, "", temp_node);

    return temp_node;
}

compiler::Node* compiler::Parser::constant_expression()
{
    Node* temp_node = assignment_expression();

    temp_node = new Node(NodeType::CONST_EXPRESSION, "", temp_node);

    return temp_node;
}

compiler::Node* compiler::Parser::statement()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() == TokenType::LBRA)
    {
        temp_node = compound_statement();
    }
    else if (m_lex->current_token_type() == TokenType::IF)
    {
        return selection_statement();
    }
    else if (m_lex->current_token_type() == TokenType::WHILE ||
             m_lex->current_token_type() == TokenType::DO_WHILE ||
             m_lex->current_token_type() == TokenType::FOR)
    {
        temp_node = iteration_statement();
    }
    else if (m_lex->current_token_type() == TokenType::FUNCTION)
    {
        temp_node = function_statement();
    }
    else if (m_lex->current_token_type() == TokenType::RETURN ||
             m_lex->current_token_type() == TokenType::BREAK ||
             m_lex->current_token_type() == TokenType::CONTINUE)
    {
        return operator_statement();
    }
    else
    {
        return expression_statement();
    }

    temp_node = new Node(NodeType::STATEMENT, "", temp_node);


    return temp_node;
}

compiler::Node* compiler::Parser::compound_statement()
{
    m_lex->next_token();

    Node* temp_node = statement_list();

    return temp_node;
}

compiler::Node* compiler::Parser::statement_list()
{
    Node* temp_node = nullptr;


    while (m_lex->current_token_type() != TokenType::RBRA)
    {
        auto temp_statement = statement();
        temp_node = new Node(NodeType::STATEMENT_LIST, "", temp_node, temp_statement);
    }
    m_lex->next_token();


    return temp_node;
}

compiler::Node* compiler::Parser::expression_statement()
{
    Node* temp_node = expression();

    if (m_lex->current_token_type() != TokenType::SEMICOLON)
    {
        error("';' expected!");
    }
    m_lex->next_token();

    return temp_node;
}

compiler::Node* compiler::Parser::selection_statement()
{
    Node* temp_node = new Node(NodeType::IF);

    m_lex->next_token();

    temp_node->operand1 = parenthesized_expression();
    temp_node->operand2 = statement();


    if (m_lex->current_token_type() == TokenType::ELSE)
    {
        temp_node->type = NodeType::IF_ELSE;
        m_lex->next_token();

        temp_node->operand3 = statement();
    }


    return temp_node;
}

compiler::Node* compiler::Parser::iteration_statement()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() == TokenType::WHILE)
    {
        temp_node = new Node(NodeType::WHILE);

        m_lex->next_token();

        temp_node->operand1 = parenthesized_expression();
        temp_node->operand2 = statement();
    }
    else if (m_lex->current_token_type() == TokenType::DO_WHILE)
    {
        temp_node = new Node(NodeType::DO_WHILE);

        m_lex->next_token();

        temp_node->operand2 = statement();

        if (m_lex->current_token_type() != TokenType::WHILE)
        {
            error("'while' expected!");
        }
        m_lex->next_token();

        temp_node->operand1 = parenthesized_expression();
    }
    else if (m_lex->current_token_type() == TokenType::FOR)
    {
        temp_node = new Node(NodeType::FOR);

        m_lex->next_token();

        if (m_lex->current_token_type() != TokenType::LPAR)
        {
            error("'(' expected!");
        }

        m_lex->next_token();
        auto for_variable = expression();

        if (m_lex->current_token_type() != TokenType::SEMICOLON)
        {
            error("';' expected!");
        }
        m_lex->next_token();


        auto for_test = expression();

        if (m_lex->current_token_type() != TokenType::SEMICOLON)
        {
            error("';' expected!");
        }
        m_lex->next_token();


        auto for_action = expression();

        if (m_lex->current_token_type() != TokenType::RPAR)
        {
            error("')' expected!");
        }

        m_lex->next_token();

        temp_node->operand1 = for_variable;
        temp_node->operand2 = for_test;
        temp_node->operand3 = for_action;
        temp_node->operand4 = statement();


        auto temp_stmt = new Node(NodeType::STATEMENT, "");

        temp_stmt->operand1 = temp_node;
        temp_node = temp_stmt;
    }


    return temp_node;
}

compiler::Node* compiler::Parser::declaration_statement()
{
    Node* temp_node = nullptr;

    bool is_const = false;

    if (m_lex->current_token_type() == TokenType::LET)
    {
        temp_node = new Node(NodeType::VARIABLE_DECLARATION);
        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::CONST)
    {
        temp_node = new Node(NodeType::CONSTANT_DECLARATION);
        m_lex->next_token();
        is_const = true;
    }

    if (m_lex->current_token_type() != TokenType::NON_TERMINAL)
    {
        error("Name of variable expected!");
    }

    string variable_name = m_lex->current_token().lexeme();
    m_lex->next_token();


    auto temp_variable_type = declaration_type();


    if (!is_const)
    {
        temp_node = new Node(NodeType::VARIABLE_DECLARATION, variable_name, temp_variable_type);
    }
    else
    {
        temp_node = new Node(NodeType::CONSTANT_DECLARATION, variable_name, temp_variable_type);
    }

    return temp_node;
}

compiler::Node* compiler::Parser::declaration_type()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() != TokenType::COLON)
    {
        error("Type of variable expected!");
    }
    m_lex->next_token();


    if (!Token::is_this_type_is_type_of_variable(m_lex->current_token_type()))
    {
        error("Type of variable expected!");
    }

    auto variable_type = Token::what_type_of_lexeme(m_lex->current_token().lexeme());
    m_lex->next_token();


    temp_node = new Node(NodeType::VARIABLE_TYPE, variable_type);


    if (m_lex->current_token_type() == TokenType::LSQR)
    {
        auto current_type = (int)variable_type;
        auto new_array_type = TokenType(current_type << 4);

        temp_node->value = new_array_type;
        m_lex->next_token();

        if (m_lex->current_token_type() != TokenType::RSQR)
        {
            error("']' expected!");
        }
        m_lex->next_token();
    }

    return temp_node;
}

compiler::Node* compiler::Parser::initializer()
{
    Node* temp_node = nullptr;

    m_lex->next_token();

    while (m_lex->current_token_type() != TokenType::RSQR)
    {
        auto temp_initializer_list = initializer_list();
        temp_node = new Node(NodeType::INITIALIZER_LIST, "", temp_node, temp_initializer_list);
    }
    m_lex->next_token();

    temp_node = new Node(NodeType::INITIALIZER, "", temp_node);

    return temp_node;
}

compiler::Node* compiler::Parser::initializer_list()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() == TokenType::COMMA)
    {
        m_lex->next_token();

        temp_node = initializer_list();
    }
    else
    {
        temp_node = assignment_expression();
    }

    return temp_node;
}

compiler::Node* compiler::Parser::function_statement()
{
    Node* temp_node = nullptr;

    m_lex->next_token();

    if (m_lex->current_token_type() != TokenType::NON_TERMINAL)
    {
        error("Name of function expected!");
    }

    string function_name = m_lex->current_token().lexeme();
    m_lex->next_token();

    auto temp_function_args = function_argument_list();


    if (m_lex->current_token_type() != TokenType::COLON)
    {
        error("':' expected!");
    }
    m_lex->next_token();

    if (!Token::is_this_type_is_type_of_variable(m_lex->current_token_type()))
    {
        error("Type of function expected!");
    }
    auto function_type = Token::what_type_of_lexeme(m_lex->current_token().lexeme());
    m_lex->next_token();


    auto temp_function_compound_statement = statement();

    auto temp_function_return_type = new Node(NodeType::FUNCTION_IMPLEMENTATION_RETURN_TYPE, function_type);

    temp_node = new Node(NodeType::FUNCTION_IMPLEMENTATION, function_name, temp_function_return_type,
                         temp_function_args, temp_function_compound_statement);

    return temp_node;
}

compiler::Node* compiler::Parser::function_argument_list()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() != TokenType::LPAR)
    {
        error("'(' expected!");
    }
    m_lex->next_token();

    while (m_lex->current_token_type() != TokenType::RPAR)
    {
        auto temp_function_argument = function_argument();

        temp_node = new Node(NodeType::FUNCTION_IMPLEMENTATION_ARGS, "", temp_node, temp_function_argument);

        if (m_lex->current_token_type() == TokenType::COMMA)
        {
            m_lex->next_token();
        }
    }


    if (m_lex->current_token_type() != TokenType::RPAR)
    {
        error("')' expected!");
    }
    m_lex->next_token();

    return temp_node;
}

compiler::Node* compiler::Parser::function_argument()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() != TokenType::NON_TERMINAL)
    {
        error("Name of variable expected!");
    }

    string variable_name = m_lex->current_token().lexeme();
    m_lex->next_token();


    auto temp_variable_type = declaration_type();


    temp_node = new Node(NodeType::FUNCTION_IMPLEMENTATION_ARG, variable_name, temp_variable_type);

    return temp_node;
}

compiler::Node* compiler::Parser::operator_statement()
{
    Node* temp_node = nullptr;

    if (m_lex->current_token_type() == TokenType::RETURN)
    {
        m_lex->next_token();
        auto temp_expression_statement = expression_statement();

        temp_node = new Node(NodeType::RETURN, 0, temp_expression_statement);
    }
    else if (m_lex->current_token_type() == TokenType::BREAK)
    {
        m_lex->next_token();
        temp_node = new Node(NodeType::BREAK, 0);
        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::CONTINUE)
    {
        m_lex->next_token();
        temp_node = new Node(NodeType::CONTINUE, 0);
        m_lex->next_token();
    }
    else if (m_lex->current_token_type() == TokenType::NEW)
    {
        m_lex->next_token();
        temp_node = postfix_expression();
        temp_node = new Node(NodeType::NEW, 0, temp_node);
    }

    return temp_node;
}

void compiler::Parser::generate()
{
    m_asm->generate();
}

   