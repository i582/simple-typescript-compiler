#include <token/Token.h>
#include "variable.h"

compiler::Variable::Variable(const std::string& variable_name, compiler::VariableType variable_type, size_t block_id,
                             bool is_const)
{
    this->m_variable_name = variable_name;
    this->m_variable_type = variable_type;


    this->m_block_id = block_id;
    this->m_is_const = is_const;
    this->m_is_global = false;
    this->m_is_argument = false;
}

void compiler::Variable::print() const
{
    cout << "name: '" << m_variable_name << "' with type: '" << variable_type_to_string(m_variable_type) << "' in block: '"
         << m_block_id << "'" << endl;
}

std::string compiler::Variable::name() const
{
    return m_variable_name;
}

bool compiler::Variable::is_const() const
{
    return m_is_const;
}

bool compiler::Variable::has_equal_type(const compiler::Variable& rhs_)
{
    return m_variable_type == rhs_.m_variable_type &&
           m_is_const == rhs_.m_is_const;
}

compiler::VariableType compiler::Variable::type() const
{
    return m_variable_type;
}

bool compiler::Variable::is_array() const
{
    return (size_t)m_variable_type >= (size_t)VariableType::NUMBER_ARRAY;
}

compiler::VariableType compiler::Variable::variable_type_from_token_type(compiler::TokenType token_type_)
{
    auto value = (int)token_type_;
    return VariableType(value);
}

bool compiler::Variable::is_types_reducible(VariableType type1, VariableType type2)
{
    return type1 == type2 || type2 == VariableType::ANY;
}

std::string compiler::Variable::variable_type_to_string(VariableType type)
{
    switch (type)
    {
        case VariableType::UNDEFINED:
            return "undefined";
        case VariableType::NUMBER:
            return "number";
        case VariableType::BOOLEAN:
            return "boolean";
        case VariableType::VOID:
            return "void";
        case VariableType::STRING:
            return "string";
        case VariableType::NUMBER_ARRAY:
            return "number[]";
        case VariableType::BOOLEAN_ARRAY:
            return "boolean[]";
        case VariableType::VOID_ARRAY:
            return "void[]";
        case VariableType::STRING_ARRAY:
            return "string[]";
        default:
            return "not defined, possible error";
    }
}

void compiler::Variable::block_id(size_t block_id)
{
    m_block_id = block_id;
}

size_t compiler::Variable::block_id() const
{
    return m_block_id;
}

bool compiler::Variable::is_array_type(compiler::VariableType type)
{
    return (size_t)type >= (size_t)VariableType::NUMBER_ARRAY;
}

std::string compiler::Variable::name_with_postfix() const
{
    return m_variable_name + std::to_string(m_block_id);
}

compiler::VariableType compiler::Variable::type_of_array_type(VariableType type)
{
    return (VariableType)(size_t(type) >> 4);
}

compiler::VariableType compiler::Variable::type_variable_value(VariableValue value)
{
    VariableType type = VariableType::UNDEFINED;

    std::visit(overload {
        [&](const number& n)
        {
            type = VariableType::NUMBER;
        },
        [&](const string& s)
        {
            type = VariableType::STRING;
        },
        [&](const bool b)
        {
            type = VariableType::BOOLEAN;
        }
    }, value);

    return type;
}

size_t compiler::Variable::byte_on_type(VariableType type)
{
    switch (type)
    {
        case VariableType::UNDEFINED:
            return 0;
        case VariableType::NUMBER:
            return 4;
        case VariableType::BOOLEAN:
            return 4;
        case VariableType::STRING:
            return 4;
        case VariableType::VOID:
            return 0;
        case VariableType::ANY:
            return 0;
        case VariableType::NUMBER_ARRAY:
            return 4;
        case VariableType::BOOLEAN_ARRAY:
            return 4;
        case VariableType::STRING_ARRAY:
            return 4;
        case VariableType::VOID_ARRAY:
            return 0;
        default:
            return 0;
    }
}

void compiler::Variable::is_global_variable(bool is_global_variable)
{
    m_is_global = is_global_variable;
}

bool compiler::Variable::is_global_variable() const
{
    return m_is_global;
}

bool compiler::Variable::is_argument_variable() const
{
    return m_is_argument;
}

void compiler::Variable::is_argument_variable(bool is_argument_variable)
{
    m_is_argument = is_argument_variable;
}
