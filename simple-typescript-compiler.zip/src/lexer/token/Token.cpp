#include "Token.h"

compiler::Token::Token(const std::string& lexeme, size_t line, size_t pos)
{
    this->m_lexeme = lexeme;
    this->m_type = what_type_of_lexeme(lexeme);

    this->m_line = line;
    this->m_pos = pos;
}

compiler::TokenType compiler::Token::type() const
{
    return m_type;
}

std::string compiler::Token::lexeme() const
{
    return m_lexeme;
}

size_t compiler::Token::line() const
{
    return m_line;
}

size_t compiler::Token::pos() const
{
    return m_pos;
}

compiler::TokenType compiler::Token::what_type_of_lexeme(const std::string& lexeme)
{
    if (is_number(lexeme))
        return TokenType::NUMBER_CONST;

    if (is_string(lexeme))
        return TokenType::STRING_CONST;

    // variables
    if (lexeme == "let")
        return TokenType::LET;
    if (lexeme == "const")
        return TokenType::CONST;
    
    // types
    if (lexeme == "number")
        return TokenType::NUMBER;
    if (lexeme == "boolean")
        return TokenType::BOOLEAN;
    if (lexeme == "void")
        return TokenType::VOID;
    if (lexeme == "string")
        return TokenType::STRING;


    // cycles
    if (lexeme == "for")
        return TokenType::FOR;
    if (lexeme == "while")
        return TokenType::WHILE;
    if (lexeme == "do")
        return TokenType::DO_WHILE;


    // cycles addition
    if (lexeme == "break")
        return TokenType::BREAK;
    if (lexeme == "continue")
        return TokenType::CONTINUE;
    
    // conditions
    if (lexeme == "if")
        return TokenType::IF;
    if (lexeme == "else")
        return TokenType::ELSE;
    
    // relationship operators
    if (lexeme == ">")
        return TokenType::GREATER;
    if (lexeme == "<")
        return TokenType::LESS;
    if (lexeme == "<=")
        return TokenType::LESS_EQUAL;
    if (lexeme == ">=")
        return TokenType::GREATER_EQUAL;
    
    // equal operators
    if (lexeme == "==")
        return TokenType::EQUAL;
    if (lexeme == "!=")
        return TokenType::NOT_EQUAL;
    
    // logical operators
    if (lexeme == "&&")
        return TokenType::AND;
    if (lexeme == "||")
        return TokenType::OR;

    // math operators
    if (lexeme == "+")
        return TokenType::PLUS;
    if (lexeme == "-")
        return TokenType::MINUS;
    if (lexeme == "*")
        return TokenType::STAR;
    if (lexeme == "/")
        return TokenType::SLASH;
    if (lexeme == "++")
        return TokenType::INC;
    if (lexeme == "--")
        return TokenType::DEC;
    if (lexeme == "**")
        return TokenType::STAR_STAR;

    // brackets
    if (lexeme == "{")
        return TokenType::LBRA;
    if (lexeme == "}")
        return TokenType::RBRA;
    if (lexeme == "(")
        return TokenType::LPAR;
    if (lexeme == ")")
        return TokenType::RPAR;
    if (lexeme == "[")
        return TokenType::LSQR;
    if (lexeme == "]")
        return TokenType::RSQR;


    // assign
    if (lexeme == "=")
        return TokenType::ASSIGN;
    if (lexeme == "+=")
        return TokenType::ADD_ASSIGN;
    if (lexeme == "-=")
        return TokenType::SUB_ASSIGN;
    if (lexeme == "*=")
        return TokenType::MUL_ASSIGN;
    if (lexeme == "/=")
        return TokenType::DIV_ASSIGN;

    // function
    if (lexeme == "function")
        return TokenType::FUNCTION;
    if (lexeme == "return")
        return TokenType::RETURN;

    // new
    if (lexeme == "new")
        return TokenType::NEW;

    // boolean values
    if (lexeme == "true")
        return TokenType::TRUE;
    if (lexeme == "false")
        return TokenType::FALSE;

    // other symbols
    if (lexeme == ";")
        return TokenType::SEMICOLON;
    if (lexeme == ":")
        return TokenType::COLON;
    if (lexeme == ",")
        return TokenType::COMMA;
    if (lexeme == ".")
        return TokenType::POINT;
    if (lexeme == "?")
        return TokenType::QUESTION;
    if (lexeme == "!")
        return TokenType::EXCLAMATION;

    // comment
    if (lexeme == "//")
        return TokenType::LINE_COMMENT;
    if (lexeme == "/*")
        return TokenType::BLOCK_COMMENT_START;
    if (lexeme == "*/")
        return TokenType::BLOCK_COMMENT_END;


    return TokenType::NON_TERMINAL;
}

bool compiler::Token::is_number(const std::string& lexeme)
{
    bool point = false;

    for (const char& s : lexeme)
    {
        if (s == '.' && !point)
        {
            point = true;
            continue;
        }

        if (s == '.')
        {
            return false;
        }

        if (s < '0' || s > '9')
        {
            return false;
        }
    }

    return true;
}

bool compiler::Token::is_string(const std::string& lexeme)
{
    return lexeme.front() == '"' && lexeme.back() == '"';
}

bool compiler::Token::is_this_type_is_type_of_variable(compiler::TokenType type)
{
    return type == TokenType::NUMBER ||
           type == TokenType::BOOLEAN ||
           type == TokenType::VOID ||
           type == TokenType::STRING;
}

bool compiler::Token::is_unary_operator(TokenType type)
{
    return type == TokenType::PLUS ||
           type == TokenType::MINUS ||
           type == TokenType::EXCLAMATION;
}

bool compiler::Token::is_assignment_operator(compiler::TokenType type)
{
    return type == TokenType::ASSIGN ||
           type == TokenType::ADD_ASSIGN ||
           type == TokenType::SUB_ASSIGN ||
           type == TokenType::MUL_ASSIGN ||
           type == TokenType::DIV_ASSIGN;
}

